# EXOGREEN Certificates

Repositorio oficial para los certificados digitales del proyecto **EXOGREEN**.

Este proyecto usa el estándar **[Blockcerts](https://www.blockcerts.org/)** para emitir y verificar certificados en blockchain.

## Estructura del Repositorio

```
exogreen-certificates/
│
├── issuer.json                       # Perfil del emisor del certificado
├── certificados/
│   ├── exogreen-badge.json          # Descripción del badge EXOGREEN
│   └── certificado-juanperez.json   # Ejemplo de certificado emitido
│
└── imagenes/
    ├── logo_exogreen.png            # Logo del proyecto (pendiente de subir)
    └── exogreen_badge.png           # Imagen del badge (pendiente de subir)
```

## Verificación

Para verificar certificados emitidos, puedes usar:

- [Blockcerts Universal Verifier](https://www.blockcerts.org/)
- [Cert-Viewer](https://github.com/blockchain-certificates/cert-viewer)
- Blockcerts Wallet (iOS/Android)

## Créditos

Emitido por **Edgar Manuel Rojas Soto**.  
Repositorio gestionado por **@edman502**.

---
*Innovación sin límites con tecnología verificable.*